
int main(){
    float valorOg, valorComDesconto;

    valorOg = 150;
    valorComDesconto = valorOg * 0.85;

    printf("%f", valorComDesconto);

    return 0;


}