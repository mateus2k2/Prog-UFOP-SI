
int main(){

    float altura, diametro, volume;

    altura = 12;
    diametro = 6;
    volume = (3.14 * (6/2) * (6/2)) * 12;

    printf("%f", volume);

    return 0;
}