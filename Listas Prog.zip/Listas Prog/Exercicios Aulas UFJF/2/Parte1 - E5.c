
int main(){
    float C, F;

    C = 78;             
    F = (9*C+160)/5;

    printf("%f", F);

    return 0;
}