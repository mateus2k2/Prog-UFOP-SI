

int main() {
int a=5;

printf(" %d\n + ",a);
printf("%d\n------",a/2);
printf("\n %d",3*a/2);

return 0;
}