

int main(){
    
    int x, x2, x3, xx;  
    
    x = 3;
    x2 = x * 2;
    x3 = x * 3;
    xx = x * x;

    printf("\nValor: %d", x);   
    printf("\nDobro: %d", x2);   
    printf("\nTriplo: %d", x3);   
    printf("\nQuadrado: %d", xx);   

    return 0;
}