#include <stdio.h>

int main(){

printf("*1111%-4d1111*",1111);

}