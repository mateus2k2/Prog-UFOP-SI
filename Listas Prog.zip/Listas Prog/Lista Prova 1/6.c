/*
Crie uma função que retorne a média de combustível gasto pelo usuário. Esta função receberá a quantidade de quilômetros rodados e a quantidade de combustível consumido.
*/

#include <stdio.h>

float calculo(float km, float comb){

}

int main(){
    
    float km, comb;

    printf("Digite a quantidade de quilômetros rodados: ");
    scanf("%f", km);

    printf("Digite a quantidade combustivel consumido: ");
    scanf("%f", comb);

    calculo(km, comb);

    return 0;

}
